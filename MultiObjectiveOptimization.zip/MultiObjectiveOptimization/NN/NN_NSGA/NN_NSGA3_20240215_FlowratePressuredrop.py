"""
Created on 2024

@author: Zhu, L.T.
If the following code is used, please cite our corresponding publications:
    https://scholar.google.com/citations?user=ZojFcCQAAAAJ&hl=zh-CN&oi=ao
"""

import random
import numpy as np
from tensorflow import keras
from tensorflow.keras.models import load_model
from deap import base, creator, tools, algorithms
import matplotlib.pyplot as plt
import csv


random_seed_value = 42
random.seed(int(random_seed_value))

# 加载神经网络模型
neural_network_flowrate = load_model('c2c3_flowrate_NN.h5')
neural_network_pressuredrop = load_model('pressuredrop_NN.h5')

#velocity_range=(0,5) #inlet velocity
#height_range=(0,0.5)#bed height

# 定义目标函数
def objective(x):
    velocity, height = x
    flowrate_prediction = neural_network_flowrate.predict([[velocity, height]])[0][0]
    pressuredrop_prediction = neural_network_pressuredrop.predict([[velocity, height]])[0][0]

    # 计算目标值
    f1 = (flowrate_prediction-0)/(0.6-0)
    f2 = (pressuredrop_prediction-1.9)/(544-1.9)

    # 如果目标函数的值超出了范围，则将其调整为范围边界的值
    f1 = max(min(f1, 1), 0)
    f2 = max(min(f2, 1), 0)

    return f1, f2

# 定义问题的边界
BOUND_LOW, BOUND_UP = [0, 0], [5, 0.5]

# 定义NSGA-III算法参数
MU = 50  # 父代个体数量
LAMBDA = 100  # 子代个体数量
NGEN = 100  # 迭代次数

# 创建适应度类
creator.create("FitnessMin", base.Fitness, weights=(1.0, -1.0))

# 创建个体类
creator.create("Individual", list, fitness=creator.FitnessMin)

# 创建工具箱
toolbox = base.Toolbox()

# 注册变量范围
toolbox.register("attr_velocity", np.random.uniform, BOUND_LOW[0], BOUND_UP[0])
toolbox.register("attr_height", np.random.uniform, BOUND_LOW[1], BOUND_UP[1])

# 注册个体和种群
toolbox.register("individual", tools.initCycle, creator.Individual, (toolbox.attr_velocity, toolbox.attr_height), n=1)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 注册目标函数
toolbox.register("evaluate", objective)

# 注册交叉和变异操作
toolbox.register("mate", tools.cxBlend, alpha=0.5)
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.2)

# 注册选择算子
toolbox.register("select", tools.selNSGA3, ref_points=tools.uniform_reference_points(nobj=2, p=12))

# 创建初始种群
pop = toolbox.population(n=MU)

# 运行NSGA-III算法
pop, _ = algorithms.eaMuPlusLambda(pop, toolbox, MU, LAMBDA, cxpb=0.7, mutpb=0.2, ngen=NGEN, stats=None, halloffame=None)

# 输出 Pareto 最优解
front = np.array([ind.fitness.values for ind in pop])
plt.scatter(front[:,0], front[:,1], marker='s', color='red')
plt.xlabel('Flowrate')
plt.ylabel('PressureDrop')
plt.title('Pareto Front (NSGA-III)')
plt.grid(True)
plt.show()

# 保存 Pareto 最优解到文件
with open('pareto_front_OptSolu_FlowratePressure_NSGA3_NN.txt', 'w') as file:
    writer = csv.writer(file, delimiter='\t')
    writer.writerow(['Objective 1', 'Objective 2', 'Velocity', 'Height'])
    for ind, fit in zip(pop, front):
        writer.writerow([fit[0], fit[1], ind[0], ind[1]])
print("Pareto Front saved to pareto_front_OptSolu_FlowratePressure_NSGA3_NN.txt")