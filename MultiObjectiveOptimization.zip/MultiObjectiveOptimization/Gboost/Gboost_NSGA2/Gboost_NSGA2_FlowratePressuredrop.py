
"""
Created on 2024

@author: Zhu, L.T.
If the following code is used, please cite our corresponding publications:
    https://scholar.google.com/citations?user=ZojFcCQAAAAJ&hl=zh-CN&oi=ao
"""

import random
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
import joblib
from deap import base, creator, tools, algorithms
import matplotlib.pyplot as plt

random_seed_value = 42
random.seed(int(random_seed_value))

# 加载Gboost模型
Gboost_flowrate = joblib.load('Gboost_flowrate.pkl')
Gboost_pressuredrop = joblib.load('Gboost_pressuredrop.pkl')


# 创建多目标优化问题
creator.create("FitnessMulti", base.Fitness, weights=(1.0, -1.0))  
creator.create("Individual", list, fitness=creator.FitnessMulti)

toolbox = base.Toolbox()

# 定义每个目标的范围
#个体的范围
#flowrate_range=(0,1)
#pressuredrop_range=(0,1)

velocity_range=(0,5) #inlet velocity
height_range=(0,0.5)#bed height


# 归一化函数
#def normalize(value, min_value, max_value):
#    return (value - min_value) / (max_value - min_value)

# 注册变量的范围
toolbox.register("velocity", random.uniform, velocity_range[0], velocity_range[1])
toolbox.register("height", random.uniform, height_range[0], height_range[1])

# 注册个体初始化方法
toolbox.register("individual", tools.initCycle, creator.Individual,
                 (toolbox.velocity, toolbox.height), n=1)

# 注册种群初始化方法
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 定义评估函数
def evaluate(individual):
    velocity, height = individual

    # 使用Gboost预测
    flowrate_prediction = Gboost_flowrate.predict([[velocity, height]])[0]
    pressuredrop_prediction = Gboost_pressuredrop.predict([[velocity, height]])[0]

    # 计算目标值
    objective1 = (flowrate_prediction-0)/(0.6-0)
    objective2 = (pressuredrop_prediction-1.9)/(544-1.9)
#    objective1 = conversion_prediction
#    objective2 = pressuredrop_prediction
    # 如果目标函数的值超出了范围，则将其调整为范围边界的值
    if objective1 < 0:
        objective1 = 0
    elif objective1 > 1:
        objective1 = 1
        
    if objective2 < 0:
        objective2 = 0
    elif objective2 > 1:
          objective2 = 1

    return objective1, objective2

# 注册评估函数
toolbox.register("evaluate", evaluate)
toolbox.register("mate", tools.cxBlend, alpha=0.5)
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.2)
toolbox.register("select", tools.selNSGA2)

# 主函数
def main():
    pop = toolbox.population(n=200)
    algorithms.eaMuPlusLambda(pop, toolbox, mu=50, lambda_=50, cxpb=0.7, mutpb=0.2, ngen=50, stats=None, halloffame=None)
    
    return pop

if __name__ == "__main__":
    population = main()
    pareto_front = tools.sortNondominated(population, len(population), first_front_only=True)[0]
    print(pareto_front)
    np.savetxt('pareto_front_FlowratePressure_NSGA2_Gboost.txt', pareto_front)

# Plot Pareto front
    plt.scatter([ind.fitness.values[0] for ind in pareto_front], [ind.fitness.values[1] for ind in pareto_front])
    plt.xlabel("Flowrate")
    plt.ylabel("pressuredrop")
    plt.title("Pareto Front")
    plt.show()

# 存储 Pareto 前沿数据到文件
pareto_data = []
for ind in pareto_front:    
    pareto_data.append(ind.fitness.values)


np.savetxt('pareto_front_OptSolu_FlowratePressure_NSGA2_Gboost.txt', pareto_data)